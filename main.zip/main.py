example="Топинамбур"
print(example[0])
print(example[-1])
print(example[5:])
print(example[::-1])
print(example[1:10:2])